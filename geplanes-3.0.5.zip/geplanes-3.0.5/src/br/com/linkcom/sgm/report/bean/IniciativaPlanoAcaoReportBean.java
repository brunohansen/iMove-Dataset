/* 
		Copyright 2007,2008,2009,2010 da Linkcom Inform�tica Ltda
		
		Este arquivo � parte do programa GEPLANES.
 	   
 	    O GEPLANES � software livre; voc� pode redistribu�-lo e/ou 
		modific�-lo sob os termos da Licen�a P�blica Geral GNU, conforme
 	    publicada pela Free Software Foundation; tanto a vers�o 2 da 
		Licen�a como (a seu crit�rio) qualquer vers�o mais nova.
 	
 	    Este programa � distribu�do na expectativa de ser �til, mas SEM 
		QUALQUER GARANTIA; sem mesmo a garantia impl�cita de 
		COMERCIALIZA��O ou de ADEQUA��O A QUALQUER PROP�SITO EM PARTICULAR. 
		Consulte a Licen�a P�blica Geral GNU para obter mais detalhes.
 	 
 	    Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral GNU  	    
		junto com este programa; se n�o, escreva para a Free Software 
		Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 
		02111-1307, USA.
		
*/
package br.com.linkcom.sgm.report.bean;

public class IniciativaPlanoAcaoReportBean {
	
	private String anoGestao;
	private String unidadeGerencial;
	private String objetivoEstrategico;
	private String iniciativa;
	private String textoOque;
	private String textoComo;
	private String textoPorque;
	private String textoQuem;
	private String data;
	private String status;
	public String getAnoGestao() {
		return anoGestao;
	}
	public String getUnidadeGerencial() {
		return unidadeGerencial;
	}
	public String getObjetivoEstrategico() {
		return objetivoEstrategico;
	}
	public String getIniciativa() {
		return iniciativa;
	}
	public String getTextoOque() {
		return textoOque;
	}
	public String getTextoComo() {
		return textoComo;
	}
	public String getTextoPorque() {
		return textoPorque;
	}
	public String getTextoQuem() {
		return textoQuem;
	}
	public String getData() {
		return data;
	}
	public String getStatus() {
		return status;
	}
	public void setAnoGestao(String anoGestao) {
		this.anoGestao = anoGestao;
	}
	public void setUnidadeGerencial(String unidadeGerencial) {
		this.unidadeGerencial = unidadeGerencial;
	}
	public void setObjetivoEstrategico(String objetivoEstrategico) {
		this.objetivoEstrategico = objetivoEstrategico;
	}
	public void setIniciativa(String iniciativa) {
		this.iniciativa = iniciativa;
	}
	public void setTextoOque(String textoOque) {
		this.textoOque = textoOque;
	}
	public void setTextoComo(String textoComo) {
		this.textoComo = textoComo;
	}
	public void setTextoPorque(String textoPorque) {
		this.textoPorque = textoPorque;
	}
	public void setTextoQuem(String textoQuem) {
		this.textoQuem = textoQuem;
	}
	public void setData(String data) {
		this.data = data;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
