====================================================================
  $Id: README.txt,v 1.1.2.2 2009/03/10 10:45:58 minhnn Exp $
====================================================================
          Quick Readme for mvnForum/mvnAd/mvnCMS Bundle Package
====================================================================

1/ This package include Tomcat that has been bundled with MVN softwares
   (mvnForum/mvnAd/mvnCMS)
   
2/ For running, open command line console
   For Windows:
      cd bin
      startup.bat
   For Linux
      cd bin
      ./startup.sh
   Then open your browser, use the below link http://localhost:8080
   Your browser will show a welcome page with help content for your evaluation
   
3/ Release Note at link:
   http://www.mvnforum.com/mvnforum/viewthread_thread,4218
   
4/ Online Wiki Documentation is at link:
   http://www.mvnforum.com/mvnforumwiki/
   
5/ The application (mvnForum/mvnAd/mvnCMS) in Tomcat is configured with embeded hsqldb
   
6/ For more information about mvnForum Professional Service, please visit:
   http://www.myvietnam.net/myvietnam/myvietnam/mvnforumservices

7/ We also provide Offshore Development and Outsourcing Service with lower cost, 
   high quality and quicker time to market solution for your projects. Please read more at:
   http://www.myvietnam.net/myvietnam/myvietnam/outsourcing
   
8/ If you have any inquiry, please do not hesitate to contact us at:
   http://www.myvietnam.net/myvietnam/myvietnam/contact 
   
9/ We include Profile of our Company as a reference.
   Please read MVN_Profile_standard_20081002.pdf


Thanks for using mvnForum

Minh Nguyen
MVN Products Manager
Huu Ngoc Joint Stock Company

