package ${package}.pages;

import java.util.Date;

/**
 * Start page of application ${artifactId}.
 */
public class Index
{
	public Date getCurrentTime() 
	{ 
		return new Date(); 
	}
}
