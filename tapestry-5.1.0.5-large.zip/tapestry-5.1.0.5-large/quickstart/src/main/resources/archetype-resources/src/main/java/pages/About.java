package ${package}.pages;

public class About
{

}
