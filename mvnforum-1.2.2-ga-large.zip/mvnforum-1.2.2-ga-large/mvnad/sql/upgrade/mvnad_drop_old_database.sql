 
DROP TABLE mvnAdBanner;
DROP TABLE mvnAdBannerZone;
DROP TABLE mvnAdPosition;
DROP TABLE mvnAdTraceClicks;
DROP TABLE mvnAdUser;
DROP TABLE mvnAdZone;
