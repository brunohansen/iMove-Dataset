/* ===========================================================
 * JFreeChart : a free chart library for the Java(tm) platform
 * ===========================================================
 *
 * (C) Copyright 2000-2008, by Object Refinery Limited and Contributors.
 *
 * Project Info:  http://www.jfree.org/jfreechart/index.html
 *
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
 * USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc.
 * in the United States and other countries.]
 *
 * ------------------------
 * XYItemRendererState.java
 * ------------------------
 * (C) Copyright 2003-2008, by Object Refinery Limited and Contributors.
 *
 * Original Author:  David Gilbert (for Object Refinery Limited);
 * Contributor(s):   Ulrich Voigt;
 *                   Greg Darke;
 *
 * Changes:
 * --------
 * 07-Oct-2003 : Version 1 (DG);
 * 27-Jan-2004 : Added workingLine attribute (DG);
 * ------------- JFREECHART 1.0.x ---------------------------------------------
 * 04-May-2007 : Added processVisibleItemsOnly flag (DG);
 * 09-Jul-2008 : Added start/endSeriesPass() methods - see patch 1997549 by
 *               Ulrich Voigt (DG);
 * 19-Sep-2008 : Added first and last item indices, based on patch by Greg
 *               Darke (DG);
 *
 */

package org.jfree.chart.renderer.xy;

import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.RendererState;
import org.jfree.data.xy.XYDataset;
import org.jfree.experimental.chart.renderer.xy.XYSmoothLineAndShapeRenderer;
import org.jfree.ui.RectangleEdge;

/**
 * The state for an {@link XYItemRenderer}.
 */
public class XYItemRendererState extends RendererState {

    /**
     * The first item in the series that will be displayed.
     *
     * @since 1.0.11
     */
    private int firstItemIndex;

    /**
     * The last item in the current series that will be displayed.
     *
     * @since 1.0.11
     */
    private int lastItemIndex;

    /**
     * A line object that the renderer can reuse to save instantiating a lot
     * of objects.
     */
    public Line2D workingLine;

    /**
     * A flag that controls whether the plot should pass ALL data items to the
     * renderer, or just the items that will be visible.
     *
     * @since 1.0.6
     */
    private boolean processVisibleItemsOnly;

    /**
     * Creates a new state.
     *
     * @param info  the plot rendering info.
     */
    public XYItemRendererState(PlotRenderingInfo info) {
        super(info);
        this.workingLine = new Line2D.Double();
        this.processVisibleItemsOnly = true;
    }

    /**
     * Returns the flag that controls whether the plot passes all data
     * items in each series to the renderer, or just the visible items.  The
     * default value is <code>true</code>.
     *
     * @return A boolean.
     *
     * @since 1.0.6
     *
     * @see #setProcessVisibleItemsOnly(boolean)
     */
    public boolean getProcessVisibleItemsOnly() {
        return this.processVisibleItemsOnly;
    }

    /**
     * Sets the flag that controls whether the plot passes all data
     * items in each series to the renderer, or just the visible items.
     *
     * @param flag  the new flag value.
     *
     * @since 1.0.6
     */
    public void setProcessVisibleItemsOnly(boolean flag) {
        this.processVisibleItemsOnly = flag;
    }

    /**
     * Returns the first item index (this is updated with each call to
     * {@link #startSeriesPass(XYDataset, int, int, int, int, int)}.
     *
     * @return The first item index.
     *
     * @since 1.0.11
     */
    public int getFirstItemIndex() {
        return this.firstItemIndex;
    }

    /**
     * Returns the last item index (this is updated with each call to
     * {@link #startSeriesPass(XYDataset, int, int, int, int, int)}.
     *
     * @return The last item index.
     *
     * @since 1.0.11
     */
    public int getLastItemIndex() {
        return this.lastItemIndex;
    }

    /**
     * This method is called by the {@link XYPlot} when it starts a pass
     * through the (visible) items in a series.  The default implementation
     * records the first and last item indices - override this method to
     * implement additional specialised behaviour.
     *
     * @param dataset  the dataset.
     * @param series  the series index.
     * @param firstItem  the index of the first item in the series.
     * @param lastItem  the index of the last item in the series.
     * @param pass  the pass index.
     * @param passCount  the number of passes.
     *
     * @see #endSeriesPass(XYDataset, int, int, int, int, int)
     *
     * @since 1.0.11
     */
    public void startSeriesPass(XYDataset dataset, int series, int firstItem,
            int lastItem, int pass, int passCount) {
        this.firstItemIndex = firstItem;
        this.lastItemIndex = lastItem;
    }

    /**
     * This method is called by the {@link XYPlot} when it ends a pass
     * through the (visible) items in a series.  The default implementation
     * does nothing, but you can override this method to implement specialised
     * behaviour.
     *
     * @param dataset  the dataset.
     * @param series  the series index.
     * @param firstItem  the index of the first item in the series.
     * @param lastItem  the index of the last item in the series.
     * @param pass  the pass index.
     * @param passCount  the number of passes.
     *
     * @see #startSeriesPass(XYDataset, int, int, int, int, int)
     *
     * @since 1.0.11
     */
    public void endSeriesPass(XYDataset dataset, int series, int firstItem,
            int lastItem, int pass, int passCount) {
        // do nothing...this is just a hook for subclasses
    }

	/**
	 * Draws the item (first pass). This method draws the lines
	 * connecting the items.
	 *
	 * @param xySmoothLineAndShapeRenderer TODO
	 * @param g2  the graphics device.
	 * @param plot  the plot (can be used to obtain standard color
	 *              information etc).
	 * @param dataset  the dataset.
	 * @param pass  the pass.
	 * @param series  the series index (zero-based).
	 * @param item  the item index (zero-based).
	 * @param domainAxis  the domain axis.
	 * @param rangeAxis  the range axis.
	 * @param dataArea  the area within which the data is being drawn.
	 */
	public void drawPrimaryLine2(XYSmoothLineAndShapeRenderer xySmoothLineAndShapeRenderer, Graphics2D g2, XYPlot plot, XYDataset dataset, int pass, int series, int item, ValueAxis domainAxis, ValueAxis rangeAxis, Rectangle2D dataArea) {
	
	    if (item == 0) {
	        return;
	    }
	
	    // get the data point...
	    double x1 = dataset.getXValue(series, item);
	    double y1 = dataset.getYValue(series, item);
	    if (Double.isNaN(y1) || Double.isNaN(x1)) {
	        return;
	    }
	
	    double x0 = dataset.getXValue(series, item - 1);
	    double y0 = dataset.getYValue(series, item - 1);
	    if (Double.isNaN(y0) || Double.isNaN(x0)) {
	        return;
	    }
	
	    RectangleEdge xAxisLocation = plot.getDomainAxisEdge();
	    RectangleEdge yAxisLocation = plot.getRangeAxisEdge();
	
	    double transX0 = domainAxis.valueToJava2D(x0, dataArea, xAxisLocation);
	    double transY0 = rangeAxis.valueToJava2D(y0, dataArea, yAxisLocation);
	
	    double transX1 = domainAxis.valueToJava2D(x1, dataArea, xAxisLocation);
	    double transY1 = rangeAxis.valueToJava2D(y1, dataArea, yAxisLocation);
	
	    // only draw if we have good values
	    if (Double.isNaN(transX0) || Double.isNaN(transY0)
	            || Double.isNaN(transX1) || Double.isNaN(transY1)) {
	        return;
	    }
	
	    java.awt.geom.Point2D.Double point0 = new java.awt.geom.Point2D.Double();
	    java.awt.geom.Point2D.Double point1 = new java.awt.geom.Point2D.Double();
	    java.awt.geom.Point2D.Double point2 = new java.awt.geom.Point2D.Double();
	    java.awt.geom.Point2D.Double point3 = new java.awt.geom.Point2D.Double();
	
	    if (item == 1) {
	        point0 = null;
	    }
	    else {
	        point0.x = domainAxis.valueToJava2D(dataset.getXValue(series,
	                item - 2), dataArea, xAxisLocation);
	        point0.y = rangeAxis.valueToJava2D(dataset.getYValue(series,
	                item - 2), dataArea, yAxisLocation);
	    }
	
	    point1.x = transX0;
	    point1.y = transY0;
	
	    point2.x = transX1;
	    point2.y = transY1;
	
	    if ((item + 1) == dataset.getItemCount(series)) {
	        point3 = null;
	    }
	    else {
	        point3.x = domainAxis.valueToJava2D(dataset.getXValue(series,
	                item + 1), dataArea, xAxisLocation);
	        point3.y = rangeAxis.valueToJava2D(dataset.getYValue(series,
	                item + 1), dataArea, yAxisLocation);
	    }
	
	    int steps = ((int) ((point2.x - point1.x) / 0.2) < 30)
	            ? (int) ((point2.x - point1.x) / 0.2) : 30;
	
	    java.awt.geom.Point2D.Double[] points = XYSmoothLineAndShapeRenderer.getBezierCurve(point0, point1, point2,
	            point3, 1, steps);
	
	    for (int i = 1; i < points.length; i++) {
	        transX0 = points[i - 1].x;
	        transY0 = points[i - 1].y;
	        transX1 = points[i].x;
	        transY1 = points[i].y;
	
	        PlotOrientation orientation = plot.getOrientation();
	        if (orientation == PlotOrientation.HORIZONTAL) {
	            workingLine.setLine(transY0, transX0, transY1, transX1);
	        }
	        else if (orientation == PlotOrientation.VERTICAL) {
	            workingLine.setLine(transX0, transY0, transX1, transY1);
	        }
	
	        if (workingLine.intersects(dataArea)) {
	            xySmoothLineAndShapeRenderer.drawFirstPassShape(g2, pass, series, item, workingLine);
	        }
	    }
	}

}
