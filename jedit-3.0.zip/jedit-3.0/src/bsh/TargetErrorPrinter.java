package bsh;

public interface TargetErrorPrinter {
	String printTargetError( Throwable t );
}

