javac $1 *.java util/*.java commands/*.java

