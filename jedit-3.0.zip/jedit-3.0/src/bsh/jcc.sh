java -classpath $HOME/javacc/JavaCC.zip COM.sun.labs.javacc.Main bsh.jj
