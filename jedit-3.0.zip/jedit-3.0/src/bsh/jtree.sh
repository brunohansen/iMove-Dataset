java -classpath $HOME/javacc/JavaCC.zip COM.sun.labs.jjtree.Main bsh.jjt
