Contents:
*.jar: Binaries that should be part of the distribution
buildlib/*.jar: Binaries used in the build process, but that should not be part
                of the distribution.

VERSIONS:

asm-3.1.jar:              ASM 3.1 (http://asm.objectweb.org)
docs.jar:                 docs-20060901-2010
dynamicjava-base.jar:     dynamicjava-20090813-r4987
forms-1.2.1.jar:          JGoodies Forms
javalanglevels-base.jar:  javalanglevels-20090223-r4766
junit.jar:                JUnit 4.4
looks-2.2.2.jar:          JGoodies Looks
platform.jar:             platform-20090812-r4985
plt.jar:                  plt-20090812-r4961

buildlib/ant-contrib.jar:           ANT Contrib 1.0b3
buildlib/cenquatasks.jar:           Distributed with Clover 1.3.9
buildlib/findbugs-ant.jar:          FindBugs 1.3.1
buildlib/junit.jar:                 JUnit 3.8.1
buildlib/plt-ant.jar:               plt-ant-20070212-2001
