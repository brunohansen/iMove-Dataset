/**
 * 
 */
package org.junit.internal.runners.statements;

import org.junit.runners.model.Statement;

public class ExpectException extends Statement {
	public Statement fNext;
	public final Class<? extends Throwable> fExpected;
	
	public ExpectException(Statement next, Class<? extends Throwable> expected) {
		fNext= next;
		fExpected= expected;
	}
	
	/**
	 * @deprecated Use {@link org.junit.runners.model.Statement#evaluate2(org.junit.internal.runners.statements.ExpectException)} instead
	 */
	@Override
	public void evaluate() throws Exception {
		fNext.evaluate2(this);
	}
}