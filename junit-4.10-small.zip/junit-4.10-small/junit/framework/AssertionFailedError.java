package junit.framework;

import junit.textui.ResultPrinter;

/**
 * Thrown when an assertion failed.
 */
public class AssertionFailedError extends AssertionError {

	private static final long serialVersionUID= 1L;

	public AssertionFailedError() {
	}

	public AssertionFailedError(String message) {
		super(defaultString(message));
	}

	private static String defaultString(String message) {
		return message == null ? "" : message;
	}

	/**
	 * @param test TODO
	 * @param resultPrinter TODO
	 * @see junit.framework.TestListener#addFailure(Test, AssertionFailedError)
	 */
	public void addFailure2(Test test, ResultPrinter resultPrinter) {
		resultPrinter.getWriter().print("F");
	}
}