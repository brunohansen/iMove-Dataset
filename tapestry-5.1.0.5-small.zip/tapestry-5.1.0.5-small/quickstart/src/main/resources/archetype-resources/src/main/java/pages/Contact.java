package ${package}.pages;

public class Contact
{

}
